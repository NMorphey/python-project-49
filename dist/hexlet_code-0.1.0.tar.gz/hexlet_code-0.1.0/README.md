### Hexlet tests and linter status:
[![Actions Status](https://github.com/NMorphey/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/NMorphey/python-project-49/actions)
### Maintainability status:
[![Maintainability](https://api.codeclimate.com/v1/badges/7eb1211020aaea7b9b83/maintainability)](https://codeclimate.com/github/NMorphey/python-project-49/maintainability)
### brain-even game asciinema:
[Click here to watch](https://asciinema.org/a/Izhu5dpBUSd5RfzRgrDvLuEth/)
